These are the example program files for the library. 

The .h file contains a converted MIDI bytestream, from a public domain MIDI.
